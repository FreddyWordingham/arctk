//! Optics module.

pub mod crossing;

pub use self::crossing::*;
