//! Colour systems.

pub mod rgb;

pub use self::rgb::*;
