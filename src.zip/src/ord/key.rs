//! Key alias.

/// Key type.
pub type Key = String;
