//! Installation information module.

pub mod dir;
pub mod exec;
