//! Interface alias.

use crate::ord::Key;

/// Interface type.
pub type Interface = (Key, Key);
